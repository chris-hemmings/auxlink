#!/bin/bash
# Build bluetoothd with album-art support for the car (AVRCP 1.6 cover art)
# and switch the Bluetooth service to it. Same BlueZ version as installed,
# plus extras/bluez-cover-art.patch (advertise cover art on PSM 0x1025, pass
# the player's image handle to the car; auxlink-cover serves the images) and
# extras/bluez-pbap-favourites.patch (tell the car the phonebook has
# favourites: PBAP 1.2, repositories local + favourites).
# Takes ~15-20 min on a Pi 4 and needs internet once.
#   sudo extras/build-bluetoothd-cover.sh          build + switch to it
#   sudo extras/build-bluetoothd-cover.sh --undo   back to the stock bluetoothd
#   extras/build-bluetoothd-cover.sh --image       (image build, in a chroot) build + set up only
set -e
[ "$(id -u)" = 0 ] || { echo "Run with sudo"; exit 1; }
HERE=$(cd "$(dirname "$0")" && pwd)
BIN=/usr/local/libexec/bluetoothd-auxlink
DROPIN=/etc/systemd/system/bluetooth.service.d/auxlink-cover-art.conf

if [ "$1" = "--undo" ]; then
  rm -f "$DROPIN"
  systemctl daemon-reload
  systemctl restart bluetooth
  echo "Back on the stock bluetoothd (album art off)."
  exit 0
fi

IMAGE=0; [ "$1" = --image ] && IMAGE=1
VER=$(dpkg-query -W -f='${Version}' bluez | sed 's/-.*//')   # e.g. 5.82
echo "Building bluetoothd from BlueZ $VER with cover art"
# The image clears apt's package lists to save space: fetch them first.
apt-get update -qq || true
apt-get install -y build-essential pkg-config wget xz-utils \
  libglib2.0-dev libdbus-1-dev libical-dev libreadline-dev libudev-dev

SRC=/usr/local/src/auxlink
mkdir -p $SRC && cd $SRC
echo "== Downloading BlueZ $VER source"
[ -f bluez-$VER.tar.xz ] || wget --progress=dot:giga https://www.kernel.org/pub/linux/bluetooth/bluez-$VER.tar.xz
rm -rf bluez-$VER-tb && mkdir bluez-$VER-tb && tar xf bluez-$VER.tar.xz -C bluez-$VER-tb --strip-components=1
cd bluez-$VER-tb
echo "== Applying the cover-art patch"
patch -p1 < "$HERE/bluez-cover-art.patch"
echo "== Applying the phonebook-favourites patch"
patch -p1 < "$HERE/bluez-pbap-favourites.patch"

# Same paths as Debian's build: pairings in /var/lib/bluetooth, config in
# /etc/bluetooth. Getting these wrong would lose every pairing.
echo "== Configuring (a few minutes, quiet)"
./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var --libexecdir=/usr/libexec \
  --disable-manpages --disable-cups --disable-midi --disable-mesh --disable-monitor \
  --disable-client --disable-tools --disable-obex --disable-sixaxis --disable-udev \
  --disable-systemd --disable-datafiles >/dev/null
grep -q '#define STORAGEDIR "/var/lib/bluetooth"' config.h || { echo "Wrong storage dir; stopping"; exit 1; }
mkdir -p lib/bluetooth
for f in lib/*.h; do ln -sf "$PWD/$f" "lib/bluetooth/$(basename "$f")"; done
make src/builtin.h >/dev/null
echo "== Compiling bluetoothd (10-15 minutes)"
make -j3 src/bluetoothd
echo "== Installing and switching the Bluetooth service over"
install -D -m 755 src/bluetoothd "$BIN"

# Start it exactly like the stock one (same arguments), plus the cover-art PSM.
UNIT=/usr/lib/systemd/system/bluetooth.service; [ -f $UNIT ] || UNIT=/lib/systemd/system/bluetooth.service
STOCK=$(sed -n 's/^ExecStart=\(\/[^ ]*bluetoothd\)\(.*\)$/\1\2/p' $UNIT | head -1)
ARGS=${STOCK#* }; [ "$ARGS" = "$STOCK" ] && ARGS=""
mkdir -p "$(dirname "$DROPIN")"
cat > "$DROPIN" <<CONF
# auxlink: bluetoothd with AVRCP cover art. Undo: build-bluetoothd-cover.sh --undo
[Service]
Environment=AUXLINK_COVER_ART_PSM=0x1025
ExecStart=
ExecStart=$BIN $ARGS
CONF
[ $IMAGE = 1 ] && { echo "bluetoothd with cover art installed"; exit 0; }
systemctl daemon-reload
systemctl enable auxlink-cover >/dev/null 2>&1 || true
systemctl restart bluetooth
sleep 3
systemctl --no-pager --lines=0 status bluetooth | head -4
echo
echo "Done. bluetoothd now advertises album art; auxlink-cover serves it."
echo "The car only reads this on a fresh pairing or reconnect: turn its Bluetooth off and on."
echo "To undo: sudo $0 --undo"
